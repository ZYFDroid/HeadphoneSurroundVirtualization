魔改自 https://github.com/HiFi-LoFi/FFTConvolver
因为C#不能调用C++里的对象，所以只能手动创建16个（C#里也需要16个）对象，然后吧每个对象的方法导出供C#使用。（结果就是地狱绘图）

WriteCode用于一键生成代码，以及性能测试