﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
namespace WriteCode
{
    internal class Program
    {

        static void Main(string[] args)
        {
            gencode();
            return;
            unsafe
            {
                float[] irarr = new float[8640];
                float[] input = new float[1024];
                float[] input2 = new float[1024];
                float[] output = new float[1024];

                irarr[2] = 1;
                irarr[16] = 0.5f;
                irarr[888] = 0.25f;
                irarr[7777] = 0.125f;

                input[9] = -1;

                List<float> f = new List<float>();

                fixed (float* irarr_ptr = irarr)
                    fixed (float* input_ptr = input)
                        fixed (float* input2_ptr = input2)
                            fixed (float* output_ptr = output)
                            {
                   Console.WriteLine(FFTConvolver.FFTConvolver.con01_init(1024, irarr_ptr, 1024));
                    
                    Stopwatch sw = Stopwatch.StartNew();
                    for (int p = 0; p < 48*100*16; p++)
                    {

                        FFTConvolver.FFTConvolver.con01_process(input_ptr, output_ptr, 1024) ;
                        
                        FFTConvolver.FFTConvolver.con01_process(input2_ptr, output_ptr, 1024);
                        

                    }
                    sw.Stop();
                    Console.WriteLine(sw.ElapsedMilliseconds);
                }


            }
            Console.WriteLine("done");
            Console.ReadLine();
        }

        private static void gencode()
        {
            String template = System.IO.File.ReadAllText("tmpin.txt");
            for (int i = 0; i < 16; i++)
            {
                string id = "" + (i + 1);
                if (id.Length < 2) { id = "0" + id; }
                Console.WriteLine(template.Replace("{id}", id));
            }
            Console.ReadLine();
        }
    }
}
